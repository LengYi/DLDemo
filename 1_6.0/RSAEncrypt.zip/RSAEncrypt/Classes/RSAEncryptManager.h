//
//  RSAEncryptManager.h
//  RSAEncrypt
//
//  Created by ice on 2017/6/5.
//  Copyright © 2017年 ice. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RSAEncryptManager : NSObject

+ (void)opensslAction:(NSInteger)type;

@end
