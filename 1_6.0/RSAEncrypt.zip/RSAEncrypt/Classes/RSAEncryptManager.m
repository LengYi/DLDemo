//
//  RSAEncryptManager.m
//  RSAEncrypt
//
//  Created by ice on 2017/6/5.
//  Copyright © 2017年 ice. All rights reserved.
//

#import "RSAEncryptManager.h"

@implementation RSAEncryptManager
+ (void)opensslAction:(NSInteger)type{
    switch (type) {
        case 0:
            
            break;
            
        default:
            break;
    }
}

@end
