//
//  ActionManager.h
//  DLRouter-Example
//
//  Created by ice on 2017/5/23.
//  Copyright © 2017年 ice. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ActionManager : NSObject
+ (void)dealAction:(NSInteger)index;
@end
